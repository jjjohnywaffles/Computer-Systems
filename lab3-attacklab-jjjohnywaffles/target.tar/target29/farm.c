/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_209(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_383()
{
    return 2445773128U;
}

unsigned addval_442(unsigned x)
{
    return x + 2462550344U;
}

unsigned getval_411()
{
    return 2425393368U;
}

unsigned addval_363(unsigned x)
{
    return x + 1479218576U;
}

void setval_176(unsigned *p)
{
    *p = 1481981731U;
}

unsigned addval_308(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_488()
{
    return 3281096792U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_480(unsigned x)
{
    return x + 2430634824U;
}

unsigned addval_427(unsigned x)
{
    return x + 2496563550U;
}

unsigned addval_163(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_115(unsigned x)
{
    return x + 3676360329U;
}

void setval_119(unsigned *p)
{
    *p = 3526410889U;
}

unsigned getval_267()
{
    return 2497743176U;
}

unsigned addval_131(unsigned x)
{
    return x + 3374895497U;
}

unsigned addval_240(unsigned x)
{
    return x + 3281178249U;
}

void setval_191(unsigned *p)
{
    *p = 3525366153U;
}

unsigned getval_312()
{
    return 2447411528U;
}

void setval_453(unsigned *p)
{
    *p = 3682910873U;
}

unsigned getval_483()
{
    return 3536113289U;
}

unsigned addval_435(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_268(unsigned x)
{
    return x + 3372798337U;
}

unsigned getval_375()
{
    return 3674788297U;
}

void setval_322(unsigned *p)
{
    *p = 3247489673U;
}

unsigned addval_310(unsigned x)
{
    return x + 3286273352U;
}

void setval_499(unsigned *p)
{
    *p = 3374367369U;
}

unsigned addval_116(unsigned x)
{
    return x + 3675836809U;
}

void setval_356(unsigned *p)
{
    *p = 2428668345U;
}

unsigned addval_105(unsigned x)
{
    return x + 3676361113U;
}

unsigned addval_137(unsigned x)
{
    return x + 3353381192U;
}

unsigned getval_223()
{
    return 3281047177U;
}

void setval_159(unsigned *p)
{
    *p = 3674784409U;
}

unsigned addval_243(unsigned x)
{
    return x + 3224948360U;
}

unsigned getval_392()
{
    return 3380920985U;
}

unsigned addval_459(unsigned x)
{
    return x + 3676360321U;
}

unsigned getval_325()
{
    return 3676360333U;
}

void setval_417(unsigned *p)
{
    *p = 3677933963U;
}

void setval_248(unsigned *p)
{
    *p = 3229929865U;
}

unsigned addval_408(unsigned x)
{
    return x + 3674260105U;
}

void setval_293(unsigned *p)
{
    *p = 2430634824U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
